"""
Tests for LLM Service
"""

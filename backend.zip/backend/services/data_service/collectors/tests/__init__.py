"""
Tests for Data Collectors
"""
